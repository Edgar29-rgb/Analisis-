/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Danielmced
 */
@Entity
@Table(name = "facturadetalle")
@NamedQueries({
    @NamedQuery(name = "Facturadetalle.findAll", query = "SELECT f FROM Facturadetalle f")})
public class Facturadetalle implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idfacturadetalle")
    private Integer idfacturadetalle;
    @Basic(optional = false)
    @Column(name = "cantidadproducto")
    private int cantidadproducto;
    @JoinColumn(name = "idfactura", referencedColumnName = "idfactura")
    @ManyToOne(optional = false)
    private Factura idfactura;
    @JoinColumn(name = "idproducto", referencedColumnName = "idproducto")
    @ManyToOne(optional = false)
    private Producto idproducto;

    public Facturadetalle() {
    }

    public Facturadetalle(Integer idfacturadetalle) {
        this.idfacturadetalle = idfacturadetalle;
    }

    public Facturadetalle(Integer idfacturadetalle, int cantidadproducto) {
        this.idfacturadetalle = idfacturadetalle;
        this.cantidadproducto = cantidadproducto;
    }

    public Integer getIdfacturadetalle() {
        return idfacturadetalle;
    }

    public void setIdfacturadetalle(Integer idfacturadetalle) {
        this.idfacturadetalle = idfacturadetalle;
    }

    public int getCantidadproducto() {
        return cantidadproducto;
    }

    public void setCantidadproducto(int cantidadproducto) {
        this.cantidadproducto = cantidadproducto;
    }

    public Factura getIdfactura() {
        return idfactura;
    }

    public void setIdfactura(Factura idfactura) {
        this.idfactura = idfactura;
    }

    public Producto getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(Producto idproducto) {
        this.idproducto = idproducto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idfacturadetalle != null ? idfacturadetalle.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Facturadetalle)) {
            return false;
        }
        Facturadetalle other = (Facturadetalle) object;
        if ((this.idfacturadetalle == null && other.idfacturadetalle != null) || (this.idfacturadetalle != null && !this.idfacturadetalle.equals(other.idfacturadetalle))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gt.edu.umg.storeprojectbackend.entity.Facturadetalle[ idfacturadetalle=" + idfacturadetalle + " ]";
    }
    
}
