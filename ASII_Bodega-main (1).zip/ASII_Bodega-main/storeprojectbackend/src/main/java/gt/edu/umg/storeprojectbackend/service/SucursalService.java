/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.service;

import gt.edu.umg.storeprojectbackend.dao.ISucursalDAO;
import gt.edu.umg.storeprojectbackend.entity.Sucursal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Danielmced
 */
@Service
public class SucursalService {
    
    @Autowired
    private ISucursalDAO sucursalDao;
    
    public List<Sucursal> getAll(){
        return (List<Sucursal>) sucursalDao.findAll();
    }
    
    public void save(Sucursal sucursal){
        sucursalDao.save(sucursal);
    }
    
    public void delete(Sucursal sucursal){
        sucursalDao.delete(sucursal);
    }
}
