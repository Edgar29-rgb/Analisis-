/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Danielmced
 */
@Entity
@Table(name = "tiposolicitud")
@NamedQueries({
    @NamedQuery(name = "Tiposolicitud.findAll", query = "SELECT t FROM Tiposolicitud t")})
public class Tiposolicitud implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtiposolicitud")
    private Integer idtiposolicitud;
    @Basic(optional = false)
    @Column(name = "tiposolicitud")
    private String tiposolicitud;

    public Tiposolicitud() {
    }

    public Tiposolicitud(Integer idtiposolicitud) {
        this.idtiposolicitud = idtiposolicitud;
    }

    public Tiposolicitud(Integer idtiposolicitud, String tiposolicitud) {
        this.idtiposolicitud = idtiposolicitud;
        this.tiposolicitud = tiposolicitud;
    }

    public Integer getIdtiposolicitud() {
        return idtiposolicitud;
    }

    public void setIdtiposolicitud(Integer idtiposolicitud) {
        this.idtiposolicitud = idtiposolicitud;
    }

    public String getTiposolicitud() {
        return tiposolicitud;
    }

    public void setTiposolicitud(String tiposolicitud) {
        this.tiposolicitud = tiposolicitud;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtiposolicitud != null ? idtiposolicitud.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tiposolicitud)) {
            return false;
        }
        Tiposolicitud other = (Tiposolicitud) object;
        if ((this.idtiposolicitud == null && other.idtiposolicitud != null) || (this.idtiposolicitud != null && !this.idtiposolicitud.equals(other.idtiposolicitud))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gt.edu.umg.storeprojectbackend.entity.Tiposolicitud[ idtiposolicitud=" + idtiposolicitud + " ]";
    }
    
}
