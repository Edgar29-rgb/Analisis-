/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.controller;

import gt.edu.umg.storeprojectbackend.entity.Marca;
import gt.edu.umg.storeprojectbackend.entity.Producto;
import gt.edu.umg.storeprojectbackend.service.ProductoService;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Danielmced
 */
@RestController
@RequestMapping("/producto")
public class ProductoController {
    
    @Autowired
    private ProductoService productoservice;
    
    @GetMapping("getall")
    public List<Producto> getAll(){
        return productoservice.getAll();
    }
    
    @PostMapping("save")
    public void save(
            @RequestParam Integer idproducto,
            @RequestParam String nombre,
            @RequestParam String descripcion,
            @RequestParam String preciounidad,
            @RequestParam String precio,
            @RequestParam Integer idmarca,
            HttpServletResponse response){
        Marca marca = new Marca(idmarca);
        Producto producto = new Producto(idproducto,nombre,descripcion,preciounidad,precio,marca);
        try {
            productoservice.save(producto);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }        
    }
    
    @PostMapping("delete")
    public void delete(
            @RequestParam Integer idproducto,
            HttpServletResponse response){
        Producto producto = new Producto(idproducto);
        try {
            productoservice.delete(producto);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }        
    }
}
