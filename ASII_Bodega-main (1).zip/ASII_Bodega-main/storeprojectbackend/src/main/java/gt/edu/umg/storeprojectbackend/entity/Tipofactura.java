/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Danielmced
 */
@Entity
@Table(name = "tipofactura")
@NamedQueries({
    @NamedQuery(name = "Tipofactura.findAll", query = "SELECT t FROM Tipofactura t")})
public class Tipofactura implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtipofactura")
    private Integer idtipofactura;
    @Column(name = "tipofactura")
    private String tipofactura;

    public Tipofactura() {
    }

    public Tipofactura(Integer idtipofactura) {
        this.idtipofactura = idtipofactura;
    }

    public Integer getIdtipofactura() {
        return idtipofactura;
    }

    public void setIdtipofactura(Integer idtipofactura) {
        this.idtipofactura = idtipofactura;
    }

    public String getTipofactura() {
        return tipofactura;
    }

    public void setTipofactura(String tipofactura) {
        this.tipofactura = tipofactura;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtipofactura != null ? idtipofactura.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tipofactura)) {
            return false;
        }
        Tipofactura other = (Tipofactura) object;
        if ((this.idtipofactura == null && other.idtipofactura != null) || (this.idtipofactura != null && !this.idtipofactura.equals(other.idtipofactura))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gt.edu.umg.storeprojectbackend.entity.Tipofactura[ idtipofactura=" + idtipofactura + " ]";
    }
    
}
