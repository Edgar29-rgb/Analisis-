/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.controller;

import gt.edu.umg.storeprojectbackend.entity.Sucursal;
import gt.edu.umg.storeprojectbackend.entity.Tiposucursal;
import gt.edu.umg.storeprojectbackend.service.SucursalService;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Danielmced
 */
@RestController
@RequestMapping("/sucursal")
public class SucursalController {
    
    @Autowired
    private SucursalService sucursalservice;
    
    @GetMapping("getall")
    public List<Sucursal> getAll(){
        return sucursalservice.getAll();
    }
    
    @PostMapping("save")
    public void save(
            @RequestParam Integer idsucursal,
            @RequestParam String nombre,
            @RequestParam String direccion,
            @RequestParam Integer idtiposucursal,
            HttpServletResponse response){
        Tiposucursal tiposuc = new Tiposucursal(idtiposucursal,null);
        Sucursal sucursal = new Sucursal(idsucursal,nombre,direccion,tiposuc);
        try {
            sucursalservice.save(sucursal);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }        
    }
    
    @PostMapping("delete")
    public void delete(
            @RequestParam Integer idsucursal,
            HttpServletResponse response){
        Sucursal sucursal = new Sucursal(idsucursal);
        try {
            sucursalservice.delete(sucursal);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }        
    }
}
