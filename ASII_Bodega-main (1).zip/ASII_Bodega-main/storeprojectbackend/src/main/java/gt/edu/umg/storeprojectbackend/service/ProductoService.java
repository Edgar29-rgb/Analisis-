/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.service;

import gt.edu.umg.storeprojectbackend.dao.IProductoDAO;
import gt.edu.umg.storeprojectbackend.entity.Producto;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Danielmced
 */
@Service
public class ProductoService {
    
    @Autowired
    private IProductoDAO productoDao;
    
    public List<Producto> getAll(){
        return (List<Producto>) productoDao.findAll();
    }
    
    public void save(Producto producto){
        productoDao.save(producto);
    }
    
    public void delete(Producto producto){
        productoDao.delete(producto);
    }
}
