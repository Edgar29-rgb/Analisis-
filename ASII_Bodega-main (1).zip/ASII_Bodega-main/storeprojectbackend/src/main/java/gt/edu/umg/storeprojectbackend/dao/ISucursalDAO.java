/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.dao;

import gt.edu.umg.storeprojectbackend.entity.Sucursal;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author Danielmced
 */
public interface ISucursalDAO extends CrudRepository<Sucursal,Integer>{
    
}
