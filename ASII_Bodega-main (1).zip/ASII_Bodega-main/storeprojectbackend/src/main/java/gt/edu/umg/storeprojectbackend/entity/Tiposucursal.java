/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Danielmced
 */
@Entity
@Table(name = "tiposucursal")
@NamedQueries({
    @NamedQuery(name = "Tiposucursal.findAll", query = "SELECT t FROM Tiposucursal t")})
public class Tiposucursal implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtiposucursal")
    private Integer idtiposucursal;
    @Basic(optional = false)
    @Column(name = "tiposucursal")
    private String tiposucursal;

    public Tiposucursal() {
    }

    public Tiposucursal(Integer idtiposucursal) {
        this.idtiposucursal = idtiposucursal;
    }

    public Tiposucursal(Integer idtiposucursal, String tiposucursal) {
        this.idtiposucursal = idtiposucursal;
        this.tiposucursal = tiposucursal;
    }

    public Integer getIdtiposucursal() {
        return idtiposucursal;
    }

    public void setIdtiposucursal(Integer idtiposucursal) {
        this.idtiposucursal = idtiposucursal;
    }

    public String getTiposucursal() {
        return tiposucursal;
    }

    public void setTiposucursal(String tiposucursal) {
        this.tiposucursal = tiposucursal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtiposucursal != null ? idtiposucursal.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tiposucursal)) {
            return false;
        }
        Tiposucursal other = (Tiposucursal) object;
        if ((this.idtiposucursal == null && other.idtiposucursal != null) || (this.idtiposucursal != null && !this.idtiposucursal.equals(other.idtiposucursal))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gt.edu.umg.storeprojectbackend.entity.Tiposucursal[ idtiposucursal=" + idtiposucursal + " ]";
    }
    
}
