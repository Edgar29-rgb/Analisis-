/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Danielmced
 */
@Entity
@Table(name = "transacciones")
@NamedQueries({
    @NamedQuery(name = "Transacciones.findAll", query = "SELECT t FROM Transacciones t")})
public class Transacciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtransacciones")
    private Integer idtransacciones;
    @Basic(optional = false)
    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @Column(name = "estado")
    private String estado;
    @JoinColumn(name = "idsucursalemisora", referencedColumnName = "idsucursal")
    @ManyToOne(optional = false)
    private Sucursal idsucursalemisora;
    @JoinColumn(name = "idsucursalreceptora", referencedColumnName = "idsucursal")
    @ManyToOne(optional = false)
    private Sucursal idsucursalreceptora;
    @JoinColumn(name = "idtiposolicitud", referencedColumnName = "idtiposolicitud")
    @ManyToOne(optional = false)
    private Tiposolicitud idtiposolicitud;

    public Transacciones() {
    }

    public Transacciones(Integer idtransacciones) {
        this.idtransacciones = idtransacciones;
    }

    public Transacciones(Integer idtransacciones, Date fecha) {
        this.idtransacciones = idtransacciones;
        this.fecha = fecha;
    }

    public Integer getIdtransacciones() {
        return idtransacciones;
    }

    public void setIdtransacciones(Integer idtransacciones) {
        this.idtransacciones = idtransacciones;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Sucursal getIdsucursalemisora() {
        return idsucursalemisora;
    }

    public void setIdsucursalemisora(Sucursal idsucursalemisora) {
        this.idsucursalemisora = idsucursalemisora;
    }

    public Sucursal getIdsucursalreceptora() {
        return idsucursalreceptora;
    }

    public void setIdsucursalreceptora(Sucursal idsucursalreceptora) {
        this.idsucursalreceptora = idsucursalreceptora;
    }

    public Tiposolicitud getIdtiposolicitud() {
        return idtiposolicitud;
    }

    public void setIdtiposolicitud(Tiposolicitud idtiposolicitud) {
        this.idtiposolicitud = idtiposolicitud;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtransacciones != null ? idtransacciones.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Transacciones)) {
            return false;
        }
        Transacciones other = (Transacciones) object;
        if ((this.idtransacciones == null && other.idtransacciones != null) || (this.idtransacciones != null && !this.idtransacciones.equals(other.idtransacciones))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gt.edu.umg.storeprojectbackend.entity.Transacciones[ idtransacciones=" + idtransacciones + " ]";
    }
    
}
