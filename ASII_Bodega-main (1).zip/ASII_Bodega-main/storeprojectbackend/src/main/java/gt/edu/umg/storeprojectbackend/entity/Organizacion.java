/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.umg.storeprojectbackend.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Danielmced
 */
@Entity
@Table(name = "organizacion")
@NamedQueries({
    @NamedQuery(name = "Organizacion.findAll", query = "SELECT o FROM Organizacion o")})
public class Organizacion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idorganizacion")
    private Integer idorganizacion;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "direccion")
    private String direccion;
    @Basic(optional = false)
    @Column(name = "email")
    private String email;
    @JoinColumn(name = "idtipoorganizacion", referencedColumnName = "idtipoorganizacion")
    @ManyToOne(optional = false)
    private Tipoorganizacion idtipoorganizacion;

    public Organizacion() {
    }

    public Organizacion(Integer idorganizacion) {
        this.idorganizacion = idorganizacion;
    }

    public Organizacion(Integer idorganizacion, String nombre, String direccion, String email) {
        this.idorganizacion = idorganizacion;
        this.nombre = nombre;
        this.direccion = direccion;
        this.email = email;
    }

    public Integer getIdorganizacion() {
        return idorganizacion;
    }

    public void setIdorganizacion(Integer idorganizacion) {
        this.idorganizacion = idorganizacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Tipoorganizacion getIdtipoorganizacion() {
        return idtipoorganizacion;
    }

    public void setIdtipoorganizacion(Tipoorganizacion idtipoorganizacion) {
        this.idtipoorganizacion = idtipoorganizacion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idorganizacion != null ? idorganizacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Organizacion)) {
            return false;
        }
        Organizacion other = (Organizacion) object;
        if ((this.idorganizacion == null && other.idorganizacion != null) || (this.idorganizacion != null && !this.idorganizacion.equals(other.idorganizacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gt.edu.umg.storeprojectbackend.entity.Organizacion[ idorganizacion=" + idorganizacion + " ]";
    }
    
}
