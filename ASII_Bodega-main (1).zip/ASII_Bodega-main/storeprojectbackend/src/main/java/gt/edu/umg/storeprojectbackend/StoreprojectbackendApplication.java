package gt.edu.umg.storeprojectbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreprojectbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreprojectbackendApplication.class, args);
	}

}
