<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="sucursal"
      :search="search"
      sort-by="idagencias"
      class="elevation-1"
    >
      <template v-slot:top>
        <v-toolbar flat>
          <v-toolbar-title>Agencias</v-toolbar-title>
          <v-spacer></v-spacer>
          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Search"
            single-line
            hide-details
          ></v-text-field>
          <v-divider class="mx-4" inset vertical></v-divider>
          <v-spacer></v-spacer>
          <v-dialog v-model="dialog" max-width="500px">
            <template v-slot:activator="{ on, attrs }">
              <v-btn color="primary" dark class="mb-2" v-bind="attrs" v-on="on">
                Agregar
              </v-btn>
            </template>

            <v-card>
              <v-card-title>
                <span class="headline">{{ formTitle }}</span>
              </v-card-title>

              <v-card-text>
                <v-container>
                  <v-row>
                    <v-col cols="12" sm="6" md="4" id="cod" hidden>
                      <v-text-field
                        v-model="editedItem.idsucursal"
                        label="Codigo agencia"
                        disabled
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12">
                      <v-text-field
                        v-model="editedItem.nombre"
                        label="Nombre"
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12">
                      <v-text-field
                        v-model="editedItem.direccion"
                        label="Direccion"
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="4" id="cod" >
                      <v-text-field
                        v-model="editedItem.idtiposucursal.idtiposucursal"
                        label="Codigo sucursal"
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12" hidden>
                      <v-text-field
                        v-model="editedItem.idtiposucursal.tiposucursal"
                        label="Sucursal"
                      ></v-text-field>
                    </v-col>
                  </v-row>
                </v-container>
              </v-card-text>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn color="blue darken-1" text @click="close">
                  Cancelar
                </v-btn>
                <v-btn color="blue darken-1" text @click="save">
                  Guardar
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-dialog v-model="dialogDelete" max-width="510px">
            <v-card>
              <v-card-title class="headline"
                >¿Seguro que quieres eliminar?</v-card-title
              >
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn color="blue darken-1" text @click="closeDelete"
                  >Cancelar</v-btn
                >
                <v-btn color="blue darken-1" text @click="deleteitemConfirm()"
                  >OK</v-btn
                >
                <v-spacer></v-spacer>
              </v-card-actions>
            </v-card>
          </v-dialog>
        </v-toolbar>
      </template>
      <template v-slot:[`item.actions`]="{ item }">
        <v-icon small class="mr-2" @click="editItem(item)"> mdi-pencil </v-icon>
        <v-icon small @click="deleteItem(item)"> mdi-delete </v-icon>
      </template>
      <template v-slot:no-data>
        <v-btn color="primary" @click="initialize"> Vuelve a intentar </v-btn>
      </template>
    </v-data-table>
  </div>
</template>

<script>
import comunication from "@/logic/comunication";
export default {
  data() {
    return {
      search: "",
      dialog: false,
      dialogDelete: false,

      headers: [
        { text: "Codigo", align: "start", value: "idsucursal" },
        { text: "Nombre", value: "nombre" },
        { text: "Direccion", value: "direccion" },
        {
          text: "Codigo Sucursal",
          value: "idtiposucursal.idtiposucursal",
          align: " d-none",
        },
        { text: "Sucursal", value: "idtiposucursal.tiposucursal" },
        { text: "Acciones", value: "actions", sortable: false },
      ],
      sucursal: [],
      editedIndex: -1,
      editedItem: {
        idsucursal: 0,
        nombre: "",
        direccion: "",
        idtiposucursal: {
          idtiposucursal: 0,
          tiposucursal: "",
        },
      },
      defaultItem: {
        idsucursal: 0,
        nombre: "",
        direccion: "",
        idtiposucursal: {
          idtiposucursal: 0,
          tiposucursal: "",
        },
      },
    };
  },

  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "NUEVA AGENCIA" : "EDITAR AGENCIA";
    },
  },

  watch: {
    dialog(val) {
      val || this.close();
    },
    dialogDelete(val) {
      val || this.closeDelete();
    },
  },

  created() {
    this.initialize();
  },

  methods: {
    async initialize() {
      let datos = await comunication.getAllAgencias();
      this.sucursal = datos.data;
    },

    async save() {
      await comunication.saveAgencias(this.editedItem);
      this.close();
    },

    async deleteitemConfirm() {      
      await comunication.deleteAgencia(this.editedItem);
      this.closeDelete();
    },

    editItem(item) {
      this.editedIndex = this.sucursal.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialog = true;
    },

    deleteItem(item) {
      this.editedIndex = this.sucursal.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialogDelete = true;
    },    

    close() {
      this.dialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    closeDelete() {
      this.dialogDelete = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
  },
};
</script>