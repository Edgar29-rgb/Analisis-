import axios from "axios";

const ENDPOINT_PATH = "http://localhost:9000/";

export default {
    getAllAgencias() {
        return axios.get(ENDPOINT_PATH + "sucursal/getall");
    },

    saveAgencias(agencia) {
        axios.post(ENDPOINT_PATH + "sucursal/save", null, {
            params: {
                idsucursal: agencia.idsucursal,
                nombre: agencia.nombre,
                direccion: agencia.direccion,
                idtiposucursal: agencia.idtiposucursal.idtiposucursal
            }
        });
    },

    deleteAgencia(agencia){
        axios.post(ENDPOINT_PATH + "sucursal/delete", null,{
            params: {
                idsucursal: agencia.idsucursal
            }
        })
    },

    getAllProductos(){
        return axios.get(ENDPOINT_PATH + "producto/getall");
    },

    saveProducto(producto) {
        axios.post(ENDPOINT_PATH + "producto/save", null, {
            params: {
                idproducto: producto.idproducto,
                nombre: producto.nombre,
                descripcion: producto.descripcion,
                preciounidad: producto.preciounidad,
                precio: producto.precio,
                idmarca: producto.idmarca.idmarca
            }
        });
    },

    deleteProducto(producto){
        axios.post(ENDPOINT_PATH + "producto/delete", null,{
            params: {
                idproducto: producto.idproducto
            }
        })
    },
}