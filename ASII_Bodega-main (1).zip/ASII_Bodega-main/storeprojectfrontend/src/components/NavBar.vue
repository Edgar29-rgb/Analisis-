  <template>
  <flex>
    <v-toolbar dark prominent shrink-on-scroll>
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>

      <v-toolbar-title>Bodegas Manager</v-toolbar-title>
    </v-toolbar>
    <v-navigation-drawer
      v-model="drawer"
      absolute
      temporary
      class="blue lighten-5"
    >
      <v-list nav dense>
        <v-list-item-group
          v-model="group"
          active-class="blue-lighten--text text--accent-4"
        >
          <v-divider></v-divider>

          <v-list-item link to="/agencias">
            <v-list-item-icon>
              <v-icon>mdi-store</v-icon>
            </v-list-item-icon>
            <v-list-item-title>Agencias</v-list-item-title>
          </v-list-item>

          <v-divider></v-divider>

          <v-list-item link to="/productos">
            <v-list-item-icon>
              <v-icon>mdi-flower</v-icon>
            </v-list-item-icon>
            <v-list-item-title>Productos</v-list-item-title>
          </v-list-item>
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>
  </flex>
</template>


<script>
export default {
  name: "NavBar",
  components: {},
  data() {
    return {
      drawer: false,
      group: null,
    };
  },
  watch: {
    group() {
      this.drawer = false;
    },
  },
};
</script>

<style>
</style>