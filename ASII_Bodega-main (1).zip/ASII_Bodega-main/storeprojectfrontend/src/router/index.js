import Vue from 'vue'
import VueRouter from 'vue-router'
import Agencias from '@/views/Agencias.vue'
import Home from '@/views/Home.vue'
import Producto from '@/views/Producto.vue'

Vue.use(VueRouter)

const routes = [
  { path: '/', component: Home},
  { path: '/agencias', component: Agencias},
  { path: '/productos', component: Producto}
]

const router = new VueRouter({
  routes
})

export default router
