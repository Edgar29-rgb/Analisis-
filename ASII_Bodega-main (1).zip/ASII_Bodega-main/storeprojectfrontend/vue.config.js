module.exports = {
  devServer: {
    port: 8089,
    proxy: 'http://localhost:9000/'
  },
  transpileDependencies: [
    'vuetify'
  ]
}
